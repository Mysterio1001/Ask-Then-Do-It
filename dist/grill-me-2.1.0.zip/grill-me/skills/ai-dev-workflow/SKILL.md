---
name: ai-dev-workflow
description: Coordinate repository-aware software development through requirement, specification, ticket-planning, test-driven implementation, and independent-review gates. Use for substantial new features, ambiguous requests, cross-module changes, architectural work, or explicit requests for a structured end-to-end development workflow. Do not invoke implicitly for trivial, fully specified fixes, formatting-only edits, or single-line changes.
---

# AI Dev Workflow

Keep orchestration thin. Discover the current stage, invoke the stage-specific skill, preserve approval state, and prevent premature implementation.

<!-- Maintainer note: A thin orchestrator avoids recreating the rigid monolithic workflow this suite is designed to replace. -->

## Declare capabilities

Before selecting or invoking a workflow stage, state the strongest capability profile proven in the current runtime:

- `conversation` can exchange text and produce user-managed artifacts.
- `tools` additionally requires actual repository read/write access, artifact persistence, and command execution.
- `multi_agent` additionally requires isolated worker or reviewer contexts.

If a required tool or isolation mechanism is unavailable, downgrade to the strongest proven profile. Never claim repository changes, test execution, persistence, parallel independence, or completed review evidence outside the declared profile. End an unsupported stage with the limitation, required handoff, and safe next action.

## Operating rules

- Match user-facing communication and generated documents to the user's language. Default to Traditional Chinese only when no preference is discoverable.
- Read applicable repository instructions before acting. Preserve user changes and follow existing project conventions.
- Answer questions from repository evidence instead of asking the user. Ask only for product decisions, unavailable context, or choices with material tradeoffs.
- Treat requirement consensus, specification approval, and ticket-plan approval as separate human gates.
- Never modify implementation code, install dependencies, or cause external side effects before all applicable gates pass.
- If implementation evidence contradicts an approved artifact, return to the earliest affected gate. Never silently redefine the requirement.

## Decide whether to orchestrate

Use the full workflow when the request is ambiguous, consequential, cross-cutting, architectural, or explicitly invokes this skill. For a small and fully specified change, explain briefly that the lightweight path applies and handle it normally unless the user explicitly requests the gated workflow.

## Discover the current stage

Perform focused, read-only reconnaissance:

1. Read applicable instruction files and repository documentation.
2. Inspect the project structure, relevant code and tests, current version-control state, and existing spec or plan conventions.
3. Locate artifacts for the requested feature.
4. Determine the first unmet condition in this order:

| Evidence | Next action |
| --- | --- |
| Important decisions remain ambiguous | Invoke `$grill-requirements` |
| Consensus exists but no specification exists | Invoke `$write-spec` |
| Specification is draft or disputed | Present or revise it and obtain approval |
| Approved specification exists but no ticket plan exists | Invoke `$plan-tickets` |
| Ticket plan is draft or disputed | Present or revise it and obtain approval |
| Approved tickets remain | Invoke `$implement-tdd` for the next eligible ticket |
| Implementation changed | Invoke `$review-code` |
| Review has no blocking findings and verification passes | Hand off the completed result |

Do not force users to replay completed stages. Verify that an existing artifact is relevant, internally consistent, and explicitly approved before relying on it.

## Enforce the gates

At each gate:

1. Lead with the proposed outcome and material tradeoffs.
2. Request explicit approval.
3. Record approval in the artifact by changing its status from `Draft` to `Approved`.
4. Continue only after the status and conversation agree.

Treat silence, an unrelated reply, or previous approval of another artifact as no approval.

## Coordinate tickets

- Execute tickets in dependency order.
- Parallelize only tickets explicitly marked safe whose contracts are settled and whose files and core abstractions do not overlap.
- When the runtime supports subagents, give each one only its approved ticket, relevant spec sections, necessary repository instructions, and ownership boundary.
- Integrate all parallel results centrally and run the combined verification suite before review.
- Prefer sequential execution whenever independence is uncertain.

## Finish

Report the delivered behavior, approved artifacts, tickets completed, test evidence, review outcome, residual risks, and any intentionally deferred work. Do not claim completion while required verification or blocking review findings remain.
