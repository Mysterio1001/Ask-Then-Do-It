---
name: review-code
description: Independently review software changes against approved requirements, specifications, tickets, tests, and repository conventions, with actionable findings prioritized by severity. Use for current diffs, completed tickets, pull requests, explicit code-review requests, or the final review stage of the AI development workflow. A review request authorizes diagnosis and reporting, not implementation of fixes.
---

# Review Code

Review from evidence rather than the implementer's narrative. Optimize for defects the author would act on, not for commentary volume.

<!-- Maintainer note: Withholding the implementer's conclusions reduces anchoring and preserves the value of an independent pass. -->

Match user-facing communication and generated artifacts to the user's language when discoverable.

## Create an independent view

When the runtime permits, delegate the review to a fresh subagent that did not implement the change. Provide only:

- Applicable repository instructions.
- Approved specification and ticket.
- Final diff and relevant surrounding code.
- Test changes and raw verification results.

Do not provide the implementer's defenses, expected findings, or a proposed verdict. Ask the reviewer to inspect the artifacts as a normal review task. If independent execution is unavailable, deliberately rebuild context from the same raw artifacts before reviewing.

## Label evidence and independence

Choose and state the Review label before findings:

- Use `independent` only when a fresh reviewer context did not implement the change and was not anchored by implementer conclusions.
- Use `non-independent` when the same context implemented the change or isolation cannot be demonstrated.
- Use `limited-evidence` when only user-supplied excerpts or incomplete raw artifacts are available; also state whether the reviewer context is independent.

Never use a stronger label than the available evidence and runtime isolation can prove.

## Review in priority order

1. Verify every changed behavior against the approved specification and acceptance criteria.
2. Trace correctness, state transitions, failure paths, compatibility, and regressions.
3. Examine trust boundaries, authorization, validation, secrets, privacy, and destructive behavior.
4. Evaluate whether tests would fail for the likely defects and whether important paths are missing.
5. Check maintainability and coupling, including shotgun surgery, feature envy, data clumps, duplicated policy, leaky abstractions, and shallow modules that add navigation without hiding complexity.

Ignore purely stylistic preferences unless they create a material maintenance, correctness, or repository-convention problem.

## Validate each finding

For every proposed finding:

- Confirm it is introduced or exposed by the reviewed change.
- Identify the concrete input, state, or sequence that triggers it.
- Check surrounding code for an existing guard or invariant.
- State the user or system impact.
- Point to the tightest relevant file and line location.
- Assign severity: `P0` catastrophic, `P1` urgent, `P2` normal, or `P3` minor.

Do not report speculation as fact. State uncertainty and the missing evidence when verification is impossible.

## Report findings first

List actionable findings in descending severity. Use a short title followed by one concise paragraph explaining trigger, impact, and remediation direction. Keep locations precise.

After findings, state:

- Verification performed and evidence unavailable.
- Residual risks and untested areas.
- Whether the approved ticket appears complete.

If no actionable findings exist, say so explicitly and still identify residual risks or verification gaps. Do not modify code unless the user separately asks for fixes.

Emit a Review Report that includes or unambiguously conveys `artifact_type`, stable `artifact_id`, shared `workflow_id`, `core_version` `2.0.0`, review `status`, reviewed `inputs`, `assumptions`, `deferred` checks, and the next `handoff`. Preserve the stated Review label, evidence unavailable, residual risks, untested areas, and completion assessment in the artifact.
